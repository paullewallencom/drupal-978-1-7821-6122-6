If you'd like to open the artwork file, I suggest using Inkscape: download it for free at inkscape.org!

Happy theming :)